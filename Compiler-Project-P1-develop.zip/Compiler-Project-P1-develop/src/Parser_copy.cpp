#include "Parser.h"

AST *Parser::parse()
{
  AST *Res = parseCalc(); // reads all the code till "eoi"
  expect(Token::eoi);
  return Res;
}

AST *Parser::parseCalc()
{
  // در کل، آی دی(نام متغیر) ها با پوش بک درون ورز ریخته میشود
  if (Tok.is(Token::KW_type)) // its' for "type int <identifier>, <identifier>,... ,<identifier>;"
  {
    llvm::SmallVector<llvm::StringRef, 8> Vars;
    advance(); // read next token
    if (expect(Token::KW_int)) // the next token should be "int"
    {
      goto _error;
    }

    advance();// read next token (after "int")
    if (expect(Token::ident))//the next token after "int" should be identifier(name)
    {
      goto _error;
    }
    Vars.push_back(Tok.getText());//if it's an identifier, then we save it in the Vars vector

    advance();// read next token(after "type int <identifier>")
    while (Tok.is(Token::comma))// if the token after "type int <identifier>" is comma, then we go in loop
    {
      advance();// read next token(after "type int <identifier> ,") 
      if (expect(Token::ident)) // it should be another identifier
        goto _error;
      Vars.push_back(Tok.getText()); // if it's an identifier, then we save it in the Vars vector again
      advance(); // read next token(after "type int <identifier> , <identifier>"
    }

    // after this loop we have read "type int (<identifier> ,)* <identifier> " with another token


    // if the next token isn't ";" go to error. but if it is ";" read next token and return(we're done)
    if (consume(Token::semi_colon)) 
      goto _error;

    return new typeDecl(Vars);
  }

  if (Tok.is(Token::ident))
  {

    Expr *Left = new Factor(Factor::Ident, Tok.getText());

    advance(); //read next token(after "<identifier>")
    if (expect(Token::assign)) //it should be "="
      goto _error;

    BinaryOp::Operator Op = BinaryOp::Assign;
    Expr *E;

    advance();// read next token(after "<identifier> =")
    E = parseExpr(); // E is the complete expression after "="
                      // till now we have read "<identifier> = [Expression]"
    if (expect(Token::eoi)) // we should read "eoi" now
      goto _error;

    Left = new BinaryOp(Op, Left, E); // here 
    return Left;
  }

_error: // این ینی بگا رفتی دیگه وایمیسته همرو میخونه تا تموم شه بعد میگه هه هه کیر بخور نال بهت میدم
  while (Tok.getKind() != Token::eoi)
    advance();// read next token
  return nullptr;
}

Expr *Parser::parseExpr()
{
  return parseDisjunction();
}

Expr *Parser::parseDisjunction()
{
  Expr *Left = parseConjunction();
  while (consume(Token::KW_or))
  {
    BinaryOp::Operator Op = BinaryOp::Or;
    Expr *Right = parseConjunction();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseConjunction()
{
  Expr *Left = parseComparison();
  while (consume(Token::KW_and))
  {
    BinaryOp::Operator Op = BinaryOp::And;
    Expr *Right = parseComparison();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseComparison()
{
  Expr *Left = parseEquality();
  while (Tok.isOneOf(Token::equal, Token::not_equal))
  {
    BinaryOp::Operator Op = Tok.is(Token::equal) ? BinaryOp::Equal : BinaryOp::NotEqual;
    advance();
    Expr *Right = parseEquality();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseEquality()
{
  Expr *Left = parseMoreLessEquality();
  while (Tok.isOneOf(Token::less_equal, Token::more_equal))
  {
    BinaryOp::Operator Op = Tok.is(Token::less_equal) ? BinaryOp::LessEqual : BinaryOp::GreaterEqual;
    advance();
    Expr *Right = parseMoreLessEquality();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseMoreLessEquality()
{
  Expr *Left = parseMoreLess();
  while (Tok.isOneOf(Token::less, Token::more))
  {
    BinaryOp::Operator Op = Tok.is(Token::less) ? BinaryOp::LessThan : BinaryOp::GreaterThan;
    advance();
    Expr *Right = parseMoreLess();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseMoreLess()
{
  Expr *Left = parseTerm();
  while (Tok.isOneOf(Token::plus, Token::minus))
  {
    BinaryOp::Operator Op = Tok.is(Token::plus) ? BinaryOp::Plus : BinaryOp::Minus;
    advance();
    Expr *Right = parseTerm();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseTerm()
{
  Expr *Left = parseFactor();
  while (Tok.isOneOf(Token::star, Token::slash))
  {
    BinaryOp::Operator Op =
        Tok.is(Token::star) ? BinaryOp::Mul : BinaryOp::Div;
    advance();// read next token
    Expr *Right = parseFactor();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseFactor()
{
  Expr *Res = nullptr;
  switch (Tok.getKind())
  {
  case Token::number:
    Res = new Factor(Factor::Number, Tok.getText());
    advance();// read next token
    break;
  case Token::ident:
    Res = new Factor(Factor::Ident, Tok.getText());
    advance();// read next token
    break;
  case Token::l_paren:
    advance();// read next token
    Res = parseExpr();
    if (!consume(Token::r_paren))
      break;
  default:
    if (!Res)
      error();

    /*if there was a syntax error in the parenthesis expression, then an error message 
      would have been emitted. The guard prevents a second error message from 
      being emitted(beaause it's an inner function of a recursive function and 
      if we don't do that, we'll have a lot of errors):*/
    while (!Tok.isOneOf(Token::r_paren, Token::star,
                        Token::plus, Token::minus,
                        Token::slash, Token::assign, Token::eoi))
      advance();// read next token
  }
  return Res;
}







// AST *Parser::parseCalc()
// {
//   if (Tok.is(Token::KW_type))
//   {
//     llvm::SmallVector<llvm::StringRef, 8> Vars;
//     advance();
//     if (expect(Token::KW_int))
//     {
//       goto _error;
//     }

//     advance();
//     if (expect(Token::ident))
//     {
//       goto _error;
//     }
//     Vars.push_back(Tok.getText());

//     advance();
//     while (Tok.is(Token::comma))
//     {
//       advance();
//       if (expect(Token::ident))
//         goto _error;
//       Vars.push_back(Tok.getText());
//       advance();
//     }

//     if (consume(Token::semi_colon))
//       goto _error;

//     return new typeDecl(Vars);
//   }

//   if (Tok.is(Token::KW_loopc))
//   {
//     advance();
//     ConditionStatement *Cond = parseConditionStatement();
//     if (!Cond)
//       goto _error;

//     if (expect(Token::colon))
//       goto _error;

//     if (expect(Token::KW_begin))
//       goto _error;

//     AST *Body = parse();
//     if (!Body)
//       goto _error;

//     if (expect(Token::KW_end))
//       goto _error;

//     return new LoopStatement(Cond, Body);
//   }

//   if (Tok.is(Token::KW_if))
//   {
//     advance();
//     ConditionStatement *Cond = parseConditionStatement();
//     if (!Cond)
//       goto _error;

//     if (expect(Token::colon))
//       goto _error;

//     if (expect(Token::KW_begin))
//       goto _error;

//     AST *Body = parse();
//     if (!Body)
//       goto _error;

//     if (expect(Token::KW_end))
//       goto _error;

//     llvm::SmallVector<ElifStatement *, 8> Elifs;
//     while (Tok.is(Token::KW_elif))
//     {
//       advance();
//       ConditionStatement *ElifCond = parseConditionStatement();
//       if (!ElifCond)
//         goto _error;

//       if (expect(Token::colon))
//         goto _error;

//       if (expect(Token::KW_begin))
//         goto _error;

//       AST *ElifBody = parse();
//       if (!ElifBody)
//         goto _error;

//       if (expect(Token::KW_end))
//         goto _error;

//       Elifs.push_back(new ElifStatement(ElifCond, ElifBody));
//     }

//     ElseStatement *Else = nullptr;
//     if (Tok.is(Token::KW_else))
//     {
//       advance();
//       if (expect(Token::colon))
//         goto _error;

//       if (expect(Token::KW_begin))
//         goto _error;

//       AST *ElseBody = parse();
//       if (!ElseBody)
//         goto _error;

//       if (expect(Token::KW_end))
//         goto _error;

//       Else = new ElseStatement(ElseBody);
//     }

//     return new ConditionStatement(new IfStatement(Cond, Body), Elifs, Else);
//   }

//   if (Tok.is(Token::ident))
// {
//   Expr *Left = new Factor(Factor::Ident, Tok.getText());
//   advance();
//   Assign *AssignOp = parseAssignOp();
//   if (!AssignOp)
//     goto _error;

//   llvm::SmallVector<Value *, 8> Vals; // Change made here
//   do
//   {
//     Value *Val = parseValue();
//     if (!Val)
//       goto _error;

//     Vals.push_back(Val); // Change made here

//   } while (consume(Token::comma));

//   if (expect(Token::semi_colon))
//     goto _error;

//   return new AssignStatement("int", llvm::SmallVector<Variable *, 8>{new Variable(Tok.getText())}, AssignOp, Vals); // Change made here
// }


// _error:
//   while (Tok.getKind() != Token::eoi)
//     advance();
//   return nullptr;
// }

// ConditionStatement *Parser::parseConditionStatement()
// {
//   Expr *Cond = parseExpr();
//   if (!Cond)
//     return nullptr;
//   return new ConditionStatement(Cond);
// }

// Assign *Parser::parseAssignOp()
// {
//   llvm::StringRef Op = Tok.getText();
//   if (consume(Token::assign) || consume(Token::assign_plus) || consume(Token::assign_minus) ||
//       consume(Token::assign_star) || consume(Token::assign_slash))
//   {
//     return new Assign(Op);
//   }
//   return nullptr;
// }

// Value *Parser::parseValue()
// {
//   Expr *Val = parseExpr();
//   if (!Val)
//     return nullptr;
//   return new Value(Val);
// }




//Changes
//--------------------------------------------------------------------------------------



