#include "Lexer.h"

namespace charinfo
{
  LLVM_READNONE inline bool isWhitespace(char c)
  {
    return c == ' ' || c == '\t' || c == '\f' || c == '\v' ||
           c == '\r' || c == '\n';
  }

  LLVM_READNONE inline bool isDigit(char c)
  {
    return c >= '0' && c <= '9';
  }

  LLVM_READNONE inline bool isLetter(char c)
  {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
  }
}

void Lexer::next(Token &token)
{
  while (*BufferPtr && charinfo::isWhitespace(*BufferPtr))
  {
    ++BufferPtr;
  }
  if (!*BufferPtr)
  {
    token.Kind = Token::eoi;
    return;
  }
  if (charinfo::isLetter(*BufferPtr))
  {
    const char *end = BufferPtr + 1;
    while (charinfo::isLetter(*end))
      ++end;
    llvm::StringRef Name(BufferPtr, end - BufferPtr);
    Token::TokenKind kind;

    if(Name == 'and') kind = Token::KW_and  ;
    else if(Name == 'or') kind = Token::KW_or  ;
    else if(Name == 'loopc') kind = Token::KW_loopc  ;
    else if(Name == 'int') kind = Token::KW_int  ;
    else if(Name == 'if') kind = Token::KW_if  ;
    else if(Name == 'elif') kind = Token::KW_elif  ;
    else if(Name == 'else') kind = Token::KW_else  ;
    else if(Name == 'begin') kind = Token::KW_begin  ;
    else if(Name == 'end') kind = Token::KW_and  ;
    else kind = Token::ident;
        
    formToken(token, end, kind);
    return;
  }
  else if (charinfo::isDigit(*BufferPtr))
  {
    const char *end = BufferPtr + 1;
    while (charinfo::isDigit(*end))
      ++end;
    formToken(token, end, Token::number);
    return;
  }
  else
  {
    switch (*BufferPtr)
    {
#define CASE(ch, tok)                     \
  case ch:                                \
    formToken(token, BufferPtr + 1, tok); \
    break
      CASE('+', Token::plus);
      CASE('-', Token::minus);
      CASE('*', Token::star);
      CASE('/', Token::slash);
      CASE('=', Token::assign);
      CASE('+=', Token::assign_plus);
      CASE('-=', Token::assign_minus);
      CASE('*=', Token::assign_star);
      CASE('/=', Token::assign_slash);
      CASE('%=', Token::assign_mod);
      CASE('==', Token::equal);
      CASE('!=', Token::not_equal);
      CASE('%', Token::mod);
      CASE('^', Token::power);
      CASE('<', Token::less);
      CASE('<=', Token::less_equal);
      CASE('>', Token::more);
      CASE('>=', Token::more_equal);
      CASE(':', Token::colon);
      CASE('(', Token::Token::l_paren);
      CASE(')', Token::Token::r_paren);
      CASE(';', Token::Token::semi_colon);
      CASE(',', Token::Token::comma);
#undef CASE
    default:
      formToken(token, BufferPtr + 1, Token::unknown);
    }
    return;
  }
}

void Lexer::formToken(Token &Tok, const char *TokEnd,
                      Token::TokenKind Kind)
{
  Tok.Kind = Kind;
  Tok.Text = llvm::StringRef(BufferPtr, TokEnd - BufferPtr);
  BufferPtr = TokEnd;
}