#include "Sema.h"
#include "llvm/ADT/StringSet.h"
#include "llvm/Support/raw_ostream.h"

namespace
{
  class DeclCheck : public ASTVisitor
  {
    llvm::StringSet<> Scope;
    bool HasError;

    enum ErrorType
    {
      Twice,
      Not,
      ValsMoreThanVars
    };

    void error(ErrorType ET, llvm::StringRef V)
    {
      llvm::errs() << "Variable " << V << " "
                   << (ET == Twice ? "already" : "not")
                   << " declared\n";
      HasError = true;
    }
    void error(ErrorType ET)
    {
      if (ET == ValsMoreThanVars)
      llvm::errs() << "Values are more than variables\n";
    }

  public:
    DeclCheck() : HasError(false) {}

    bool hasError() { return HasError; }


    virtual void visit(Goal &Node) override
    {
      for (auto I = Node.begin(), E = Node.end(); I != E; ++I)
      {
        (*I)->accept(*this); // Visit each child node
      }
    }

    virtual void visit(Statement &Node) override
    {
    }

      virtual void visit(IfStatement &Node) override {
    Node.getCondition()->accept(*this);

    for (auto I = Node.begin(), E = Node.end(); I != E; ++I) {
      (*I)->accept(*this); // Visit each assignment statement
    }
  }

  virtual void visit(ElifStatement &Node) override {
    Node.getCondition()->accept(*this);

    for (auto I = Node.begin(), E = Node.end(); I != E; ++I) {
      (*I)->accept(*this); // Visit each assignment statement
    }
  }

  virtual void visit(ElseStatement &Node) override {
    for (auto I = Node.begin(), E = Node.end(); I != E; ++I) {
      (*I)->accept(*this); // Visit each assignment statement
    }
  }

  virtual void visit(LoopStatement &Node) override {
    Node.getCondition()->accept(*this);

    for (auto I = Node.begin(), E = Node.end(); I != E; ++I) {
      (*I)->accept(*this); // Visit each assignment statement
    }
  }

  virtual void visit(AssignmentStatement &Node) override {
    Factor dest = Node.getLeft();
    
    dest->accept(*this);

    if (dest->getKind() == Factor::Number) {
        llvm::errs() << "Assignment destination must be an identifier.";
        HasError = true;
    }
    if (Node.getRight())
      Node.getRight()->accept(*this);
  
  }


    virtual void visit(Factor &Node) override
    {
      if (Node.getKind() == Factor::Ident)
      {
        if (Scope.find(Node.getVal()) == Scope.end())
          error(Not, Node.getVal());
      }
    };

    virtual void visit(BinaryOp &Node) override
    {
      if (Node.getLeft())
        Node.getLeft()->accept(*this);
      else
        HasError = true;
      if (Node.getRight())
        Node.getRight()->accept(*this);
      else
        HasError = true;
    };

    virtual void visit(DeclarationStatement &Node) override
    {
      for (auto I = Node.begin(), E = Node.end(); I != E; ++I)
      {
        if (!Scope.insert(*I).second)
          error(Twice, *I);
      }
    };

    virtual void visit(DeclAssignStatement &Node) override
    {
      int varlen = 0 , vallen = 0;
      for (auto I = Node.variables_begin(), E = Node.variables_end(); I != E; ++I)
        ++varlen;
      for (auto I = Node.values_begin(), E = Node.values_end(); I != E; ++I)
        ++vallen;
      if (vallen > varlen)
        error(ValsMoreThanVars);
      for (auto I = Node.variables_begin(), E = Node.variables_end(); I != E; ++I)
      {
        if (!Scope.insert(*I).second)
          error(Twice, *I);
      }


    }
  };
}

bool Sema::semantic(AST *Tree)
{
  if (!Tree)
    return false;
  DeclCheck Check;
  Tree->accept(Check);
  return Check.hasError();
}
