#include "CodeGen.h"
#include "llvm/ADT/StringMap.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLV0MContext.h"
#include "llvm/Support/raw_ostream.h"

using namespace llvm;

namespace
{
  class ToIRVisitor : public ASTVisitor
  {
    Module *M;
    IRBuilder<> Builder;
    Type *VoidTy;
    Type *Int32Ty;
    Type *Int8PtrTy;
    Type *Int8PtrPtrTy;
    Constant *Int32Zero;

    Value *V;
    StringMap<Value *> nameMap;

  public:
    ToIRVisitor(Module *M) : M(M), Builder(M->getContext())
    {
      VoidTy = Type::getVoidTy(M->getContext());
      Int32Ty = Type::getInt32Ty(M->getContext());
      Int8PtrTy = Type::getInt8PtrTy(M->getContext());
      Int8PtrPtrTy = Int8PtrTy->getPointerTo();
      Int32Zero = ConstantInt::get(Int32Ty, 0, true);
    }

    void run(AST *Tree)
    {
      FunctionType *MainFty = FunctionType::get(
          Int32Ty, {Int32Ty, Int8PtrPtrTy}, false);
      Function *MainFn = Function::Create(
          MainFty, GlobalValue::ExternalLinkage, "main", M);
      BasicBlock *BB = BasicBlock::Create(M->getContext(),
                                          "entry", MainFn);
      Builder.SetInsertPoint(BB);

      Tree->accept(*this);

      Builder.CreateRet(Int32Zero);
    }

    virtual void visit(Factor &Node) override
    {
      if (Node.getKind() == Factor::Ident)
      {
        V = nameMap[Node.getVal()];
      }
      else
      {
        int intval;
        Node.getVal().getAsInteger(10, intval);
        V = ConstantInt::get(Int32Ty, intval, true);
      }
    };

    virtual void visit(BinaryOp &Node) override
    {
      Node.getLeft()->accept(*this);
      Value *Left = V;
      Node.getRight()->accept(*this);
      Value *Right = V;
      switch (Node.getOperator())
      {
      case BinaryOp::Plus:
        V = Builder.CreateNSWAdd(Left, Right);
        break;
      case BinaryOp::Minus:
        V = Builder.CreateNSWSub(Left, Right);
        break;
      case BinaryOp::Mul:
        V = Builder.CreateNSWMul(Left, Right);
        break;
      case BinaryOp::Div:
        V = Builder.CreateSDiv(Left, Right);
        break;

case BinaryOp::Mod:
V = Builder.CreateSRem(Left, Right);
        break;



case BinaryOp::Or:
V = Builder.CreateOr(Left, Right);
        break;

        
case BinaryOp::And:
V = Builder.CreateAnd(Left, Right);
        break;

        

      case BinaryOp::Equal:
        V = Builder.CreateICmpEQ(Left, Right);
        break;
      case BinaryOp::NotEqual:
        V = Builder.CreateICmpNE(Left, Right);
        break;
      case BinaryOp::LessThan:
        V = Builder.CreateICmpSLT(Left, Right);
        break;
      case BinaryOp::GreaterThan:
        V = Builder.CreateICmpSGT(Left, Right);
        break;
      case BinaryOp::LessEqual:
        V = Builder.CreateICmpSLE(Left, Right);
        break;
      case BinaryOp::GreaterEqual:
        V = Builder.CreateICmpSGE(Left, Right);
        break;
      case BinaryOp::Assign:
        V = Builder.CreateStore(Right, Left);
        FunctionType *CalcWriteFnTy =
            FunctionType::get(VoidTy, {Int32Ty}, false);
        Function *CalcWriteFn = Function::Create(
            CalcWriteFnTy, GlobalValue::ExternalLinkage,
            "calc_write", M);
        Builder.CreateCall(CalcWriteFnTy, CalcWriteFn, {V});
        break;
      }
    };

        virtual void visit(Goal &Node) override
    {
      for (auto I = Node.begin(), E = Node.end(); I != E; ++I)
      {
        (*I)->accept(*this); // Visit each child node
      }
    }

    virtual void visit(Statement &Node) override
    {
      
    }

    vitural void visit(IfStatement &Node) override
    {

    }

     vitural void visit(ElifStatement &Node) override
    {

    }

     vitural void visit(ElseStatement &Node) override
    {

    }

     vitural void visit(Expr &Node) override
    {

    }

     vitural void visit(LoopStatement &Node) override
    {

    }
     vitural void visit(AssignmentStatement &Node) override
    {

    }

    
    virtual void visit(DeclarationStatement &Node) override
    {
      // Itera te over the variables declared in the declaration statement.
      for (auto I = Node.begin(), E = Node.end(); I != E; ++I)
      {
        StringRef Var = *I;

        // Create an alloca instruction to allocate memory for the variable.
        nameMap[Var] = Builder.CreateAlloca(Int32Ty);

        
      }
    };
    virtual void visit(DeclAssignStatement &Node) override
    {
Value *val = nullptr;

      

      auto valsI , valsE , varsI , varsE;
       // Iterate over the variables declared in the declaration statement.
      for ( valsI = Node.values_begin(), valsE = Node.values_end(),
            varsI = Node.variables_begin(),varsE = Node.variables_end() ; varsI != varsE; ++varsI, ++valsI)
      {
        StringRef Var = *varsI;
        Val = *valsI;
        // Create an alloca instruction to allocate memory for the variable.
        nameMap[Var] = Builder.CreateAlloca(Int32Ty);

        // Store the initial value (if any) in the variable's memory location.
        if (Val != nullptr)
        {
          Builder.CreateStore(Val, nameMap[Var]);
        }
        // else{
        //   Builder.CreateStore(Val, nameMap[Var]);
        // }
      }

      
    };
  };
} // namespace

void CodeGen::compile(AST *Tree)
{
  LLVMContext Ctx;
  Module *M = new Module("calc.expr", Ctx);
  ToIRVisitor ToIR(M);
  ToIR.run(Tree);
  M->print(outs(), nullptr);
}