#include "Parser.h"

AST *Parser::parse()
{
  AST *Res = parseGoal();
  expect(Token::eoi);
  return Res;
}

AST *Parser::parseGoal()
{
  llvm::SmallVector<Statement *, 8> Statements;
  while (!Tok.is(Token::eoi))
  {
    Statements.push_back(parseStatement());
  }
  return new Goal(Statements);
}

Statement *Parser::parseStatement()
{
  if (Tok.is(Token::KW_int))
  {
    advance(); // consume KW_int
    if (Tok.is(Token::ident))
    {
      return parseDeclarationOrDeclAssignStatement();
    }
    else
    {
      error();
      return nullptr;
    }
  }
  else if (Tok.is(Token::ident))
  {
    return parseAssignmentStatement();
  }
  else if (consume(Token::KW_if))
  {
    return parseIfStatement();
  }
  else if (consume(Token::KW_loop))
  {
    return parseLoopStatement();
  }
  else
  {
    error();
    advance();
    return nullptr;
  }
}

Statement *Parser::parseDeclarationOrDeclAssignStatement()
{
  llvm::SmallVector<llvm::StringRef, 8> Variables;
  llvm::SmallVector<Expr *, 8> Values;
  if (expect(Token::ident))
      return nullptr;

  Variables.push_back(Tok.getText());

  advance(); // consume identifier
  while(Tok.is(Token::comma)){
    advance(); // consume comma
    if (expect(Token::ident))
      return nullptr;
    Variables.push_back(Tok.getText());
  }


  if (Tok.is(Token::semi_colon))
  {
    advance(); // consume semi_colon
    return new DeclarationStatement(Variables);
  }
  else if (consume(Token::assign))
  {
    advance(); // consume assign
    Expr *Value = parseExpr();
    Values.push_back(Value);
    while(Tok.is(Token::comma)){
      advance(); // consume comma
      Value = parseExpr();
      Values.push_back(Value);
    }

    if (consume(Token::semi_colon))
    {
      return new DeclAssignStatement(Variables, Values);
    }
  }

  error();
  return nullptr;
}


Statement *Parser::parseAssignmentStatement()
{
  Factor *Var = new Factor(Factor::Ident, Tok.getText());
  advance(); // consume identifier


  if (consume(Token::assign) || consume(Token::assign_plus) || consume(Token::assign_minus) ||
      consume(Token::assign_star) || consume(Token::assign_slash) || consume(Token::assign_mod))
  {
    Expr *Value = parseExpr();
    if (consume(Token::semi_colon))
    {
      return new AssignmentStatement(Var, Value);
    }
  }

  error();
  return nullptr;
}

Statement *Parser::parseIfStatement()
{
  advance(); // consume KW_if
  Expr *Condition = parseExpr();

  if (expect(Token::colon))
  {
    return nullptr;
  }
  advance(); // consume colon

  if (expect(Token::KW_begin))
  {
    return nullptr;
  }
  advance(); // consume KW_begin

  llvm::SmallVector<AssignmentStatement *, 8> Assignments;
  while (!Tok.is(Token::KW_end))
  {
    Statement *Stmt = parseAssignmentStatement();
    if (Stmt)
    {
      Assignments.push_back(static_cast<AssignmentStatement *>(Stmt));
    }
    else
    {
      error();
      advance();
    }
  }

  advance(); // consume KW_end

  return new IfStatement(Condition, Assignments);
}

Statement *Parser::parseLoopStatement()
{
  advance(); // consume KW_loop
  Expr *Condition = parseExpr();

  if (expect(Token::colon))
  {
    return nullptr;
  }
  advance(); // consume colon

  if (expect(Token::KW_begin))
  {
    return nullptr;
  }
  advance(); // consume KW_begin

  llvm::SmallVector<AssignmentStatement *, 8> Assignments;
  while (!Tok.is(Token::KW_end))
  {
    Statement *Stmt = parseAssignmentStatement();
    if (Stmt)
    {
      Assignments.push_back(static_cast<AssignmentStatement *>(Stmt));
    }
    else
    {
      error();
      advance();
    }
  }

  advance(); // consume KW_end

  return new LoopStatement(Condition, Assignments);
}

Expr *Parser::parseExpr()
{
  return parseDisjunction();
}

Expr *Parser::parseDisjunction()
{
  Expr *Left = parseConjunction();
  while (consume(Token::KW_or))
  {
    BinaryOp::Operator Op = BinaryOp::Or;
    Expr *Right = parseConjunction();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseConjunction()
{
  Expr *Left = parseComparison();
  while (consume(Token::KW_and))
  {
    BinaryOp::Operator Op = BinaryOp::And;
    Expr *Right = parseComparison();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseComparison()
{
  Expr *Left = parseEquality();
  while (Tok.isOneOf(Token::equal, Token::not_equal))
  {
    BinaryOp::Operator Op = Tok.is(Token::equal) ? BinaryOp::Equal : BinaryOp::NotEqual;
    advance();
    Expr *Right = parseEquality();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseEquality()
{
  Expr *Left = parseMoreLessEquality();
  while (Tok.isOneOf(Token::less_equal, Token::more_equal))
  {
    BinaryOp::Operator Op = Tok.is(Token::less_equal) ? BinaryOp::LessEqual : BinaryOp::GreaterEqual;
    advance();
    Expr *Right = parseMoreLessEquality();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseMoreLessEquality()
{
  Expr *Left = parseMoreLess();
  while (Tok.isOneOf(Token::less, Token::more))
  {
    BinaryOp::Operator Op = Tok.is(Token::less) ? BinaryOp::LessThan : BinaryOp::GreaterThan;
    advance();
    Expr *Right = parseMoreLess();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseMoreLess()
{
  Expr *Left = parseTerm();
  while (Tok.isOneOf(Token::plus, Token::minus))
  {
    BinaryOp::Operator Op = Tok.is(Token::plus) ? BinaryOp::Plus : BinaryOp::Minus;
    advance();
    Expr *Right = parseTerm();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parseTerm()
{
  Expr *Left = parsePower();
  while (Tok.isOneOf(Token::star, Token::slash))
  {
    BinaryOp::Operator Op =
        Tok.is(Token::star) ? BinaryOp::Mul : BinaryOp::Div;
    advance();
    Expr *Right = parsePower();
    Left = new BinaryOp(Op, Left, Right);
  }
  return Left;
}

Expr *Parser::parsePower()
{
  Expr *Left = parseFactor();
  while (Tok.isOneOf(Token::power))
  {
    BinaryOp::Operator Op =
        BinaryOp::Power;
    advance();
    Expr *Right = parseFactor();
    Left = new BinaryOp(Op, Right, Left); // reverse 
  }
  return Left;
}

Expr *Parser::parseFactor()
{
  Expr *Res = nullptr;
  switch (Tok.getKind())
  {
  case Token::number:
    Res = new Factor(Factor::Number, Tok.getText());
    advance();
    break;
  case Token::ident:
    Res = new Factor(Factor::Ident, Tok.getText());
    advance();
    break;
  case Token::l_paren:
    advance();
    Res = parseExpr();
    if (!consume(Token::r_paren))
      break;
  default:
    if (!Res)
      error();
    while (!Tok.isOneOf(Token::r_paren, Token::star,
                        Token::plus, Token::minus,
                        Token::slash, Token::equal, Token::eoi))
      advance();
  }
  return Res;
}

