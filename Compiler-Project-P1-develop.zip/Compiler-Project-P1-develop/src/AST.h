#ifndef AST_H
#define AST_H

#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/StringRef.h"

class AST;
class Goal;
class Statement;
class IfStatement;
class ElifStatement;
class ElseStatement;
class LoopStatement;
class DeclarationStatement;
class DeclAssignStatement;
class AssignmentStatement;
class Expr;
class Factor;

class ASTVisitor
{
    public:
  virtual void visit(AST &){};
  virtual void visit(Goal &){};
  virtual void visit(Statement &){};
  virtual void visit(IfStatement &){};
  virtual void visit(ElifStatement &){};
  virtual void visit(ElseStatement &){};
  virtual void visit(LoopStatement &){};
  virtual void visit(DeclarationStatement &){};
  virtual void visit(DeclAssignStatement &){};
  virtual void visit(AssignmentStatement &){};
  virtual void visit(Expr &){};
  virtual void visit(Factor &){};

};

class AST
{
    public:
  virtual ~AST() {}
  virtual void accept(ASTVisitor &V) = 0;
};

class Goal : public AST
{
  using StatementVector = llvm::SmallVector<Statement *, 8>;
  StatementVector Statements;

    public:
  Goal(StatementVector Statements)
      : Statements(Statements) {}
  StatementVector::const_iterator begin() { return Statements.begin(); }
  StatementVector::const_iterator end() { return Statements.end(); }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};


class Expr : public AST
{
    public:
  Expr() {}
};

class Statement : public AST
{
    public:
  virtual ~Statement() {}
  virtual void accept(ASTVisitor &V) = 0;
};

class IfStatement : public Statement
{
  Expr *Cond;
  using AssignmentVector = llvm::SmallVector<AssignmentStatement *, 8>;
  AssignmentVector Assignments;

      public:
  IfStatement(Expr *Cond, AssignmentVector Assignments)
      : Cond(Cond), Assignments(Assignments) {}

  Expr getCondition() {return Cond;}
  AssignmentVector::const_iterator begin() { return Assignments.begin(); }
  AssignmentVector::const_iterator end() { return Assignments.end(); }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class ElifStatement : public Statement
{
  Expr *Cond;
  using AssignmentVector = llvm::SmallVector<AssignmentStatement *, 8>;
  AssignmentVector Assignments;

      public:
  ElifStatement(Expr *Cond, AssignmentVector Assignments)
      : Cond(Cond), Assignments(Assignments) {}
  
  Expr getCondition() {return Cond;}
  AssignmentVector::const_iterator begin() { return Assignments.begin(); }
  AssignmentVector::const_iterator end() { return Assignments.end(); }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class ElseStatement : public Statement
{
  using AssignmentVector = llvm::SmallVector<AssignmentStatement *, 8>;
  AssignmentVector Assignments;

    public:
  ElseStatement(AssignmentVector Assignments)
      : Assignments(Assignments) {}

  AssignmentVector::const_iterator begin() { return Assignments.begin(); }
  AssignmentVector::const_iterator end() { return Assignments.end(); }
  
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class LoopStatement : public Statement
{
  Expr *Cond;
  using AssignmentVector = llvm::SmallVector<AssignmentStatement *, 8>;
  AssignmentVector Assignments;

    public:
  LoopStatement(Expr *Cond, AssignmentVector Assignments)
      : Cond(Cond), Assignments(Assignments) {}

  Expr getCondition() {return Cond;}
  AssignmentVector::const_iterator begin() { return Assignments.begin(); }
  AssignmentVector::const_iterator end() { return Assignments.end(); }

  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class DeclarationStatement : public Statement
{
  using VariableVector = llvm::SmallVector<llvm::StringRef, 8>;
  VariableVector Variables;

    public:
  DeclarationStatement(VariableVector Variables)
      : Variables(Variables) {}
  VariableVector::const_iterator begin() { return Variables.begin(); }
  VariableVector::const_iterator end() { return Variables.end(); }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class DeclAssignStatement : public Statement
{
  using VariableVector = llvm::SmallVector<llvm::StringRef, 8>;
  using ValueVector = llvm::SmallVector<Expr *, 8>;

  VariableVector Variables;
  ValueVector Values;

    public:
  DeclAssignStatement(VariableVector Variables, ValueVector Values)
      : Variables(Variables), Values(Values) {}
  VariableVector::const_iterator variables_begin() { return Variables.begin(); }
  VariableVector::const_iterator variables_end() { return Variables.end(); }
  ValueVector::const_iterator values_begin() { return Values.begin(); }
  ValueVector::const_iterator values_end() { return Values.end(); }

  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};



class AssignmentStatement : public Statement
{
  Factor *Var;
  
  Expr *ExprValue;

    public:
  AssignmentStatement(Factor *Var, Expr *ExprValue)
      : Var(Var),  ExprValue(ExprValue) {}

  Factor *getLeft() { return Var; }

  Expr *getRight() { return ExprValue; }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class Factor : public Expr
{
  public:
  enum ValueKind
  {
    Ident,
    Number
  };

  private:
  ValueKind Kind;
  llvm::StringRef Val;

  public:
  Factor(ValueKind Kind, llvm::StringRef Val)
      : Kind(Kind), Val(Val) {}
  ValueKind getKind() { return Kind; }
  llvm::StringRef getVal() { return Val; }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

class BinaryOp : public Expr
{
    public:
  enum Operator
  {
    Plus,
    Minus,
    Mul,
    Div,
    Power,
    Assign,
    AssignMul,
    AssignDiv,
    AssignPlus,
    AssignMinus,
    Or,
    And,
    NotEqual,
    EqualEqual,
    GreaterEqual,
    LessEqual,
    GreaterThan,
    LessThan
  };

  private:
  Expr *Left;
  Expr *Right;
  Operator Op;

    public:
  BinaryOp(Operator Op, Expr *L, Expr *R)
      : Op(Op), Left(L), Right(R) {}
  Expr *getLeft() { return Left; }
  Expr *getRight() { return Right; }
  Operator getOperator() { return Op; }
  virtual void accept(ASTVisitor &V) override
  {
    V.visit(*this);
  }
};

#endif

// class Condition : public AST
// {
//   Expr *Expression;

//     public:
//   Condition(Expr *Expression)
//       : Expression(Expression) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };



// class Assign : public AST
// {
//    enum Operator
//   {
//     Assign,
//     AssignMul,
//     AssignDiv,
//     AssignPlus,
//     AssignMinus
//   };
//   Operator Op;

//     public:
//   virtual ~Assign() {}
//   virtual void accept(ASTVisitor &V) = 0;
// };

// class Variable : public AST
// {
//   ID *Name;

//     public:
//   Variable(ID *Name)
//       : Name(Name) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Value : public AST
// {
//   Expr *Expression;

//     public:
//   Value(Expr *Expression)
//       : Expression(Expression) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };



// class Expr : public AST
// {
//   Disjunction *Disj;

//     public:
//   Expr(Disjunction *Disj)
//       : Disj(Disj) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Disjunction : public AST
// {
//   Disjunction *Left;
//   Conjunction *Right;

//     public:
//   Disjunction(Disjunction *Left, Conjunction *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Conjunction : public AST
// {
//   Conjunction *Left;
//   Comparison *Right;

//     public:
//   Conjunction(Conjunction *Left, Comparison *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Comparison : public AST
// {
//   Comparison *Left;
//   Equality *Right;

//     public:
//   Comparison(Comparison *Left, Equality *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Equality : public AST
// {
//   Equality *Left;
//   MoreLessEquality *Right;

//     public:
//   Equality(Equality *Left, MoreLessEquality *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class MoreLessEquality : public AST
// {
//   MoreLessEquality *Left;
//   MoreLess *Right;

//     public:
//   MoreLessEquality(MoreLessEquality *Left, MoreLess *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class MoreLess : public AST
// {
//   MoreLess *Left;
//   Term *Right;

//     public:
//   MoreLess(MoreLess *Left, Term *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Term : public AST
// {
//   Term *Left;
//   Power *Right;

//     public:
//   Term(Term *Left, Power *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Power : public AST
// {
//   Factor *Left;
//   Power *Right;

//     public:
//   Power(Factor *Left, Power *Right)
//       : Left(Left), Right(Right) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Factor : public AST
// {
//   using FactorKind = llvm::SmallVector<Factor *, 8>;

//     public:
//   virtual ~Factor() {}
//   virtual void accept(ASTVisitor &V) = 0;
// };


// class ID : public Factor
// {
//   llvm::StringRef Name;

//     public:
//   ID(llvm::StringRef Name)
//       : Name(Name) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Number : public Factor
// {
//   llvm::StringRef Value;

//     public:
//   Number(llvm::StringRef Value)
//       : Value(Value) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };







// #ifndef AST_H
// #define AST_H

// #include "llvm/ADT/SmallVector.h"
// #include "llvm/ADT/StringRef.h"

// class AST;
// class Expr;
// class Factor;
// class BinaryOp;
// class typeDecl;
// class LoopStatement;
// class ConditionStatement;
// class IfStatement;
// class ElifStatement;
// class ElseStatement;
// class AssignStatement;
// class AdditionalAssignment;
// class Assign;
// class Variable;
// class Value;

// class ASTVisitor
// {
//     public:
//   virtual void visit(AST &){};
//   virtual void visit(Expr &){};
//   virtual void visit(Factor &) = 0;
//   virtual void visit(BinaryOp &) = 0;
//   virtual void visit(typeDecl &) = 0;
//   virtual void visit(LoopStatement &) = 0;
//   virtual void visit(ConditionStatement &) = 0;
//   virtual void visit(IfStatement &) = 0;
//   virtual void visit(ElifStatement &) = 0;
//   virtual void visit(ElseStatement &) = 0;
//   virtual void visit(AssignStatement &) = 0;
//   virtual void visit(AdditionalAssignment &) = 0;
//   virtual void visit(Assign &) = 0;
//   virtual void visit(Variable &) = 0;
//   virtual void visit(Value &) = 0;
// };

// class AST
// {
//     public:
//   virtual ~AST() {}
//   virtual void accept(ASTVisitor &V) = 0;
// };

// class Expr : public AST
// {
//     public:
//   Expr() {}
// };

// class Factor : public Expr
// {
//     public:
//   enum ValueKind
//   {
//     Ident,
//     Number
//   };

//   private:
//   ValueKind Kind;
//   llvm::StringRef Val;

//     public:
//   Factor(ValueKind Kind, llvm::StringRef Val)
//       : Kind(Kind), Val(Val) {}
//   ValueKind getKind() { return Kind; }
//   llvm::StringRef getVal() { return Val; }
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class BinaryOp : public Expr
// {
//     public:
//   enum Operator
//   {
//     Plus,
//     Minus,
//     Mul,
//     Div,
//     Assign,
//     Or,
//     And,
//     NotEqual,
//     EqualEqual,
//     GreaterEqual,
//     LessEqual,
//     GreaterThan,
//     LessThan
//   };

//   private:
//   Expr *Left;
//   Expr *Right;
//   Operator Op;

//     public:
//   BinaryOp(Operator Op, Expr *L, Expr *R)
//       : Op(Op), Left(L), Right(R) {}
//   Expr *getLeft() { return Left; }
//   Expr *getRight() { return Right; }
//   Operator getOperator() { return Op; }
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class typeDecl : public AST
// {
//   using VarVector = llvm::SmallVector<llvm::StringRef, 8>;
//   VarVector Vars;
//   Expr *E;

//     public:
//   typeDecl(llvm::SmallVector<llvm::StringRef, 8> Vars)
//       : Vars(Vars) {}
//   VarVector::const_iterator begin() { return Vars.begin(); }
//   VarVector::const_iterator end() { return Vars.end(); }
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class LoopStatement : public AST
// {
//   ConditionStatement *Condition;
//   AST *Body;

//     public:
//   LoopStatement(ConditionStatement *Cond, AST *Body)
//       : Condition(Cond), Body(Body) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class ConditionStatement : public AST
// {
//   IfStatement *If;
//   llvm::SmallVector<ElifStatement *, 8> Elifs;
//   ElseStatement *Else;

//     public:
//   ConditionStatement(IfStatement *If, llvm::SmallVector<ElifStatement *, 8> Elifs, ElseStatement *Else)
//       : If(If), Elifs(Elifs), Else(Else) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class IfStatement : public AST
// {
//   Expr *Condition;
//   AST *Body;

//     public:
//   IfStatement(Expr *Cond, AST *Body)
//       : Condition(Cond), Body(Body) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class ElifStatement : public AST
// {
//   Expr *Condition;
//   AST *Body;

//     public:
//   ElifStatement(Expr *Cond, AST *Body)
//       : Condition(Cond), Body(Body) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class ElseStatement : public AST
// {
//   AST *Body;

//     public:
//   ElseStatement(AST *Body)
//       : Body(Body) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class AssignStatement : public AST
// {
//   llvm::StringRef Type;
//   llvm::SmallVector<Variable *, 8> Vars;
//   Assign *AssignOp;
//   llvm::SmallVector<Value *, 8> Vals; // Change made here

//     public:
//   AssignStatement(llvm::StringRef Type, llvm::SmallVector<Variable *, 8> Vars, Assign *AssignOp, llvm::SmallVector<Value *, 8> Vals) // Change made here
//       : Type(Type), Vars(Vars), AssignOp(AssignOp), Vals(Vals) {} // Change made here
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class AdditionalAssignment : public AST
// {
//   Variable *Var;
//   Assign *AssignOp;
//   Value *Val;

//     public:
//   AdditionalAssignment(Variable *Var, Assign *AssignOp, Value *Val)
//       : Var(Var), AssignOp(AssignOp), Val(Val) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Assign : public AST
// {
//   llvm::StringRef Op;

//     public:
//   Assign(llvm::StringRef Op)
//       : Op(Op) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Variable : public AST
// {
//   llvm::StringRef ID;

//     public:
//   Variable(llvm::StringRef ID)
//       : ID(ID) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// class Value : public AST
// {
//   Expr *Val;

//     public:
//   Value(Expr *Val)
//       : Val(Val) {}
//   virtual void accept(ASTVisitor &V) override
//   {
//     V.visit(*this);
//   }
// };

// #endif
